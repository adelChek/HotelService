@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.hotel/")
package com.java.hotel.soap;
