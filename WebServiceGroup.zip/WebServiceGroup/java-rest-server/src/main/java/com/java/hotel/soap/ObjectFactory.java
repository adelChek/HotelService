
package com.java.hotel.soap;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.java.hotel.soap package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SetHotelRooms_QNAME = new QName("http://soap.hotel/", "setHotelRooms");
    private final static QName _GetHotelRoomsResponse_QNAME = new QName("http://soap.hotel/", "getHotelRoomsResponse");
    private final static QName _BookResponse_QNAME = new QName("http://soap.hotel/", "bookResponse");
    private final static QName _SetBookings_QNAME = new QName("http://soap.hotel/", "setBookings");
    private final static QName _Book_QNAME = new QName("http://soap.hotel/", "book");
    private final static QName _GetPersonsResponse_QNAME = new QName("http://soap.hotel/", "getPersonsResponse");
    private final static QName _SetBookingsResponse_QNAME = new QName("http://soap.hotel/", "setBookingsResponse");
    private final static QName _SetHotelRoomsResponse_QNAME = new QName("http://soap.hotel/", "setHotelRoomsResponse");
    private final static QName _GetBookingsResponse_QNAME = new QName("http://soap.hotel/", "getBookingsResponse");
    private final static QName _GetBookings_QNAME = new QName("http://soap.hotel/", "getBookings");
    private final static QName _SetPersons_QNAME = new QName("http://soap.hotel/", "setPersons");
    private final static QName _GetPersons_QNAME = new QName("http://soap.hotel/", "getPersons");
    private final static QName _GetHotelRooms_QNAME = new QName("http://soap.hotel/", "getHotelRooms");
    private final static QName _SetPersonsResponse_QNAME = new QName("http://soap.hotel/", "setPersonsResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.java.hotel.soap
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SetHotelRooms }
     * 
     */
    public SetHotelRooms createSetHotelRooms() {
        return new SetHotelRooms();
    }

    /**
     * Create an instance of {@link BookResponse }
     * 
     */
    public BookResponse createBookResponse() {
        return new BookResponse();
    }

    /**
     * Create an instance of {@link SetBookings }
     * 
     */
    public SetBookings createSetBookings() {
        return new SetBookings();
    }

    /**
     * Create an instance of {@link GetHotelRoomsResponse }
     * 
     */
    public GetHotelRoomsResponse createGetHotelRoomsResponse() {
        return new GetHotelRoomsResponse();
    }

    /**
     * Create an instance of {@link Book }
     * 
     */
    public Book createBook() {
        return new Book();
    }

    /**
     * Create an instance of {@link GetPersonsResponse }
     * 
     */
    public GetPersonsResponse createGetPersonsResponse() {
        return new GetPersonsResponse();
    }

    /**
     * Create an instance of {@link SetBookingsResponse }
     * 
     */
    public SetBookingsResponse createSetBookingsResponse() {
        return new SetBookingsResponse();
    }

    /**
     * Create an instance of {@link SetHotelRoomsResponse }
     * 
     */
    public SetHotelRoomsResponse createSetHotelRoomsResponse() {
        return new SetHotelRoomsResponse();
    }

    /**
     * Create an instance of {@link GetBookingsResponse }
     * 
     */
    public GetBookingsResponse createGetBookingsResponse() {
        return new GetBookingsResponse();
    }

    /**
     * Create an instance of {@link GetBookings }
     * 
     */
    public GetBookings createGetBookings() {
        return new GetBookings();
    }

    /**
     * Create an instance of {@link SetPersons }
     * 
     */
    public SetPersons createSetPersons() {
        return new SetPersons();
    }

    /**
     * Create an instance of {@link GetPersons }
     * 
     */
    public GetPersons createGetPersons() {
        return new GetPersons();
    }

    /**
     * Create an instance of {@link SetPersonsResponse }
     * 
     */
    public SetPersonsResponse createSetPersonsResponse() {
        return new SetPersonsResponse();
    }

    /**
     * Create an instance of {@link GetHotelRooms }
     * 
     */
    public GetHotelRooms createGetHotelRooms() {
        return new GetHotelRooms();
    }

    /**
     * Create an instance of {@link HotelBooking }
     * 
     */
    public HotelBooking createHotelBooking() {
        return new HotelBooking();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

    /**
     * Create an instance of {@link HotelRoom }
     * 
     */
    public HotelRoom createHotelRoom() {
        return new HotelRoom();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetHotelRooms }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setHotelRooms")
    public JAXBElement<SetHotelRooms> createSetHotelRooms(SetHotelRooms value) {
        return new JAXBElement<SetHotelRooms>(_SetHotelRooms_QNAME, SetHotelRooms.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHotelRoomsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getHotelRoomsResponse")
    public JAXBElement<GetHotelRoomsResponse> createGetHotelRoomsResponse(GetHotelRoomsResponse value) {
        return new JAXBElement<GetHotelRoomsResponse>(_GetHotelRoomsResponse_QNAME, GetHotelRoomsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BookResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "bookResponse")
    public JAXBElement<BookResponse> createBookResponse(BookResponse value) {
        return new JAXBElement<BookResponse>(_BookResponse_QNAME, BookResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetBookings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setBookings")
    public JAXBElement<SetBookings> createSetBookings(SetBookings value) {
        return new JAXBElement<SetBookings>(_SetBookings_QNAME, SetBookings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Book }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "book")
    public JAXBElement<Book> createBook(Book value) {
        return new JAXBElement<Book>(_Book_QNAME, Book.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPersonsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getPersonsResponse")
    public JAXBElement<GetPersonsResponse> createGetPersonsResponse(GetPersonsResponse value) {
        return new JAXBElement<GetPersonsResponse>(_GetPersonsResponse_QNAME, GetPersonsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetBookingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setBookingsResponse")
    public JAXBElement<SetBookingsResponse> createSetBookingsResponse(SetBookingsResponse value) {
        return new JAXBElement<SetBookingsResponse>(_SetBookingsResponse_QNAME, SetBookingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetHotelRoomsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setHotelRoomsResponse")
    public JAXBElement<SetHotelRoomsResponse> createSetHotelRoomsResponse(SetHotelRoomsResponse value) {
        return new JAXBElement<SetHotelRoomsResponse>(_SetHotelRoomsResponse_QNAME, SetHotelRoomsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBookingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getBookingsResponse")
    public JAXBElement<GetBookingsResponse> createGetBookingsResponse(GetBookingsResponse value) {
        return new JAXBElement<GetBookingsResponse>(_GetBookingsResponse_QNAME, GetBookingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBookings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getBookings")
    public JAXBElement<GetBookings> createGetBookings(GetBookings value) {
        return new JAXBElement<GetBookings>(_GetBookings_QNAME, GetBookings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetPersons }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setPersons")
    public JAXBElement<SetPersons> createSetPersons(SetPersons value) {
        return new JAXBElement<SetPersons>(_SetPersons_QNAME, SetPersons.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPersons }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getPersons")
    public JAXBElement<GetPersons> createGetPersons(GetPersons value) {
        return new JAXBElement<GetPersons>(_GetPersons_QNAME, GetPersons.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHotelRooms }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "getHotelRooms")
    public JAXBElement<GetHotelRooms> createGetHotelRooms(GetHotelRooms value) {
        return new JAXBElement<GetHotelRooms>(_GetHotelRooms_QNAME, GetHotelRooms.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetPersonsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.hotel/", name = "setPersonsResponse")
    public JAXBElement<SetPersonsResponse> createSetPersonsResponse(SetPersonsResponse value) {
        return new JAXBElement<SetPersonsResponse>(_SetPersonsResponse_QNAME, SetPersonsResponse.class, null, value);
    }

}
