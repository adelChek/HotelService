
package com.java.hotel.soap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour hotelBooking complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="hotelBooking">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateArrival" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dateDeparture" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="hotelRoom" type="{http://soap.hotel/}hotelRoom" minOccurs="0"/>
 *         &lt;element name="person" type="{http://soap.hotel/}person" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "hotelBooking", propOrder = {
    "dateArrival",
    "dateDeparture",
    "hotelRoom",
    "person"
})
public class HotelBooking {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateArrival;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateDeparture;
    protected HotelRoom hotelRoom;
    protected Person person;

    /**
     * Obtient la valeur de la propriété dateArrival.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateArrival() {
        return dateArrival;
    }

    /**
     * Définit la valeur de la propriété dateArrival.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateArrival(XMLGregorianCalendar value) {
        this.dateArrival = value;
    }

    /**
     * Obtient la valeur de la propriété dateDeparture.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDeparture() {
        return dateDeparture;
    }

    /**
     * Définit la valeur de la propriété dateDeparture.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDeparture(XMLGregorianCalendar value) {
        this.dateDeparture = value;
    }

    /**
     * Obtient la valeur de la propriété hotelRoom.
     * 
     * @return
     *     possible object is
     *     {@link HotelRoom }
     *     
     */
    public HotelRoom getHotelRoom() {
        return hotelRoom;
    }

    /**
     * Définit la valeur de la propriété hotelRoom.
     * 
     * @param value
     *     allowed object is
     *     {@link HotelRoom }
     *     
     */
    public void setHotelRoom(HotelRoom value) {
        this.hotelRoom = value;
    }

    /**
     * Obtient la valeur de la propriété person.
     * 
     * @return
     *     possible object is
     *     {@link Person }
     *     
     */
    public Person getPerson() {
        return person;
    }

    /**
     * Définit la valeur de la propriété person.
     * 
     * @param value
     *     allowed object is
     *     {@link Person }
     *     
     */
    public void setPerson(Person value) {
        this.person = value;
    }

}
