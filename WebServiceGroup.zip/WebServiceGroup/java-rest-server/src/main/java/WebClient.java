
import com.java.hotel.soap.HotelRoom;
import com.java.hotel.soap.HotelService;
import com.java.hotel.soap.HotelWebService;


import java.util.List;

public class WebClient {

    /**
     * This is a Service object providing the client view or the factory for proxies of the Web service from which we generated this.
     * This is used to get the proxy(stub) or port of the web service created.
     */
     HotelService service = null ;

    public WebClient(){
        /**
         * Instantiate the web service client object.
         */
        service = new HotelService();
    }

    public void testService (){
        /*
         * Get the web service proxy or port from the web service client factory. This port is nothing but the stub for the web service created.
         * It facilitates us to invoke the web service methods remotely.
         */
        HotelWebService servicePort = service.getHotelWebServicePort();

        /*
         * Invoke the web service operation using the port or stub or proxy
         */
        List<HotelRoom> hotelRooms = servicePort.getHotelRooms() ;

        for (HotelRoom hotelRoom: hotelRooms ) {
            System.out.println(hotelRoom.getType() + ' ' + hotelRoom.getPrice());
        }
    }

    public static void main (String arags[]){
        WebClient client = new WebClient() ;
        client.testService() ;
    }
}
