package infres.ws.rest.javarestserver;

import com.java.hotel.soap.HotelRoom;
import com.java.hotel.soap.HotelService;
import com.java.hotel.soap.HotelWebService;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping(path ="/rest/")
public class FlightBookingController {

    List<Flight> flights;

    /**
     * This is a Service object providing the client view or the factory for proxies of the Web service from which we generated this.
     * This is used to get the proxy(stub) or port of the web service created.
     */
    HotelService service = null ;

    @PostConstruct
    public void init() {
        flights = new ArrayList<Flight>();

        Airline airline1 = new Airline("Air France");
        Airline airline2 = new Airline("Easy Jet");
        ArrayList<Seat> seats;
        Flight f;

        // Flight 1
        seats = new ArrayList<Seat>();

        for (int i = 0; i < 10; i++) {
            seats.add(new Seat(i));
        }

        f = new Flight(airline1, seats, 100,
                new Date(2018 - 1900, 01, 25, 10, 0),
                new Date(2018 - 1900, 01, 25, 12, 30),
                "Marseille", "Bristol");

        flights.add(f);

        // Flight 2
        seats = new ArrayList<Seat>();

        for (int i = 0; i < 10; i++) {
            seats.add(new Seat(i));
        }

        f = new Flight(airline1, seats, 100,
                new Date( - 1900, 06, 11, 20, 0),
                new Date(2018 - 1900, 06, 11, 21, 30),
                "Lyon", "Marseille");

        flights.add(f);

        // Flight 3
        seats = new ArrayList<Seat>();

        for (int i = 0; i < 10; i++) {
            seats.add(new Seat(i));
        }

        f = new Flight(airline1, seats, 100,
                new Date(2018 - 1900, 10, 20, 10, 0),
                new Date(2018 - 1900, 10, 20, 12, 30),
                "Paris", "Tokyo");

        flights.add(f);

        // Flight 4
        seats = new ArrayList<Seat>();

        for (int i = 0; i < 5; i++) {
            seats.add(new Seat(i));
        }

        f = new Flight(airline2, seats, 100,
                new Date(2018 - 1900, 10, 20, 10, 0),
                new Date(2018 - 1900, 10, 20, 12, 30),
                "Montpellier", "Nice");

        flights.add(f);

        /**
         * Instantiate the web service client object.
         */
        service = new HotelService();
    }

    @CrossOrigin
    @RequestMapping(path= "flights", produces= MediaType.APPLICATION_PROBLEM_JSON_UTF8_VALUE)
    @ResponseBody
    public List<Flight> get_flights() {
        return flights;
    }

    @RequestMapping(path= "hotelRooms", produces= MediaType.APPLICATION_PROBLEM_JSON_UTF8_VALUE)
    @ResponseBody
    public List<HotelRoom> get_rooms() {
        /*
         * Get the web service proxy or port from the web service client factory. This port is nothing but the stub for the web service created.
         * It facilitates us to invoke the web service methods remotely.
         */
        HotelWebService servicePort = service.getHotelWebServicePort();

        /*
         * Invoke the web service operation using the port or stub or proxy
         */
        List<HotelRoom> hotelRooms = servicePort.getHotelRooms() ;

        return hotelRooms;
    }

}
