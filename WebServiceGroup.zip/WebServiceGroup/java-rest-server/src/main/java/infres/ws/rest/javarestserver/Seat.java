package infres.ws.rest.javarestserver;

public class Seat {

    private int numSeat;

    public Seat(int numSeat) {
        this.numSeat = numSeat;
    }

    public int getNumSeat() {
        return numSeat;
    }

    public void setNumSeat(int numSeat) {
        this.numSeat = numSeat;
    }
}
