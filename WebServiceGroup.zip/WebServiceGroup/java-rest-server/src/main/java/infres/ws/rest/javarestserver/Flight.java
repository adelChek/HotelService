package infres.ws.rest.javarestserver;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Flight {

    private Airline airline;

    private List<Seat> seats;

    private int price;

    private Date departureDate;

    private Date arrivalDate;

    private String departurePlace;

    private String arrivalPlace;

    public Flight(Airline airline, List<Seat> seats, int price,
                  Date departureDate, Date arrivalDate,
                  String departurePlace, String arrivalPlace) {
        this.airline = airline;
        this.seats = seats;
        this.price = price;
        this.departureDate = departureDate;
        this.arrivalDate = arrivalDate;
        this.departurePlace = departurePlace;
        this.arrivalPlace = arrivalPlace;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(Date departureDate) {
        this.departureDate = departureDate;
    }

    public Date getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(Date arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getDeparturePlace() {
        return departurePlace;
    }

    public void setDeparturePlace(String departurePlace) {
        this.departurePlace = departurePlace;
    }

    public String getArrivalPlace() {
        return arrivalPlace;
    }

    public void setArrivalPlace(String arrivalPlace) {
        this.arrivalPlace = arrivalPlace;
    }

    public int getPrice() { return price; }

    public void setPrice(int price) { this.price = price; }

    public Airline getAirline() { return airline; }

    public void setAirline(Airline airline) { this.airline = airline; }

    public List<Seat> getSeats() { return seats; }

    public void setSeats(List<Seat> seats) { this.seats = seats; }

}
