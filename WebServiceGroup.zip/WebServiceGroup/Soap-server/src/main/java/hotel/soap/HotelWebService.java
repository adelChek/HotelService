package hotel.soap;


import javax.jws.WebMethod;
import javax.jws.WebService;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebService(serviceName = "HotelService")
public class HotelWebService {

    private List<Person> persons;
    private List<HotelBooking> bookings;
    private List<HotelRoom> hotelRooms;


    public HotelWebService() {
        persons = new ArrayList<Person>();
        hotelRooms = new ArrayList<HotelRoom>();
        bookings = new ArrayList<HotelBooking>();

        persons.add(new Person("Thomas"));
        persons.add(new Person("David"));
        persons.add(new Person("Samantha"));

        hotelRooms = new ArrayList<HotelRoom>();
        hotelRooms.add(new HotelRoom("Chambre double Hilton", 135));
        hotelRooms.add(new HotelRoom("Chambre triple Hilton ", 150));
        hotelRooms.add(new HotelRoom("Chambre simple Hilton", 80));
        hotelRooms.add(new HotelRoom("Suite de luxe Lounge hotel", 340));
        hotelRooms.add(new HotelRoom("Hotel F1 - 1 chambre", 50));

    }

    @WebMethod
    public HotelBooking book(Person person, HotelRoom hotelRoom, Date dateArrival, Date dateDeparture){

        HotelBooking booking = new HotelBooking(person, hotelRoom, dateArrival, dateDeparture);
        bookings.add(booking);

        return booking;
    }

    @WebMethod
    public List<Person> getPersons() {
        return persons;
    }

    public void setPersons(List<Person> persons) {
        this.persons = persons;
    }

    @WebMethod
    public List<HotelBooking> getBookings() {
        return bookings;
    }

    public void setBookings(List<HotelBooking> bookings) {
        this.bookings = bookings;
    }

    @WebMethod
    public List<HotelRoom> getHotelRooms() {
        return hotelRooms;
    }

    public void setHotelRooms(List<HotelRoom> hotelRooms) {
        this.hotelRooms = hotelRooms;
    }
}
